//
//  PrimerKlarnaSDK.h
//  PrimerKlarnaSDK
//
//  Created by Illia Khrypunov on 30.10.2023.
//

#import <Foundation/Foundation.h>

//! Project version number for PrimerKlarnaSDK.
FOUNDATION_EXPORT double PrimerKlarnaSDKVersionNumber;

//! Project version string for PrimerKlarnaSDK.
FOUNDATION_EXPORT const unsigned char PrimerKlarnaSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PrimerKlarnaSDK/PublicHeader.h>


