//
//  KlarnaCore.h
//  KlarnaCore
//
//  Created by KlarnaMobileSDK Team.
//

#import <Foundation/Foundation.h>

//! Project version number for KlarnaCore.
FOUNDATION_EXPORT double KlarnaCoreVersionNumber;

//! Project version string for KlarnaCore.
FOUNDATION_EXPORT const unsigned char KlarnaCoreVersionString[];
